def lol():
    print('Welcome to my first pypi package =)')
